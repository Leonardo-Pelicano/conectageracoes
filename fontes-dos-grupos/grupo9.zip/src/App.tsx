import { useEffect, useRef, useState } from "react";

type Screen = "home" | "learn" | "quiz" | "simulator" | "help";
type Answer = "yes" | "no";

const navItems: { id: Exclude<Screen, "home">; label: string; short: string }[] = [
  { id: "learn", label: "Aprender sobre o tema", short: "Aprender" },
  { id: "quiz", label: "Essa conversa é segura?", short: "Avaliar" },
  { id: "simulator", label: "Simulador de Conversa", short: "Simular" },
  { id: "help", label: "Preciso de Ajuda", short: "Ajuda" },
];

const quizQuestions = [
  "A pessoa pediu seu nome completo, idade, escola, endereço ou localização?",
  "Ela ficou íntima ou carinhosa muito rápido, mesmo sem conhecer você bem?",
  "Pediu para manter a conversa ou a amizade em segredo?",
  "Insistiu, pressionou ou ameaçou para receber fotos ou vídeos?",
  "Ofereceu presentes, dinheiro, skins ou vantagens em troca de algo?",
  "Sugeriu um encontro presencial ou pediu para mudar para outro aplicativo?",
];

const learnSections = [
  {
    title: "O que é grooming digital?",
    tag: "ENTENDA",
    content:
      "É quando um adulto ou alguém mal-intencionado se aproxima de uma criança ou adolescente pela internet para ganhar confiança, criar segredo e manipular. Pode começar com elogios, ajuda em um jogo ou interesses em comum.",
    tip: "A culpa nunca é de quem foi enganado. Pedir ajuda é sempre a escolha certa.",
  },
  {
    title: "Sinais de alerta",
    tag: "FIQUE ATENTO",
    content:
      "Intimidade rápida, perguntas pessoais, pedidos de segredo, presentes, pressão para enviar fotos, conversas que causam desconforto e tentativas de afastar você de amigos ou da família são sinais importantes.",
    tip: "Você não precisa ser educado com quem ultrapassa seus limites. Saia da conversa.",
  },
  {
    title: "Em jogos e redes sociais",
    tag: "NA PRÁTICA",
    content:
      "Um perfil pode oferecer skins, moedas ou dicas para depois pedir seu WhatsApp, localização ou fotos. Em redes sociais, pode fingir ter a mesma idade e usar imagens de outra pessoa.",
    tip: "Mantenha o chat na plataforma, limite seu perfil e não aceite encontros.",
  },
];

const scamCards = [
  {
    title: "Phishing",
    text: "Links e páginas falsas tentam roubar sua senha. Confira o endereço e nunca faça login por links recebidos no chat.",
    mark: "PH",
  },
  {
    title: "Falso parente",
    text: "Alguém finge ser familiar e pede dinheiro com urgência. Confirme por ligação em um número que você já conhece.",
    mark: "FP",
  },
  {
    title: "Catfish",
    text: "Um perfil usa nome ou fotos falsos para criar uma relação. Imagens e videochamadas não garantem identidade.",
    mark: "CF",
  },
  {
    title: "Falso empréstimo",
    text: "Promessas de dinheiro fácil com taxa antecipada são golpe. Não envie documentos nem faça pagamentos.",
    mark: "FE",
  },
  {
    title: "Invasão de contas",
    text: "Nunca compartilhe senha ou código de verificação. Use uma senha diferente e ative a verificação em duas etapas.",
    mark: "IC",
  },
];

type SimChoice = {
  text: string;
  reply: string;
  feedback: string;
  safe: boolean;
};

const simSteps: { message: string; topic: string; choices: SimChoice[] }[] = [
  {
    message: "Oi! Você joga muito bem. Quantos anos você tem?",
    topic: "IDADE",
    choices: [
      {
        text: "Prefiro não dizer.",
        reply: "Relaxa, é só curiosidade...",
        feedback: "Boa escolha. Sua idade é um dado pessoal e você não precisa responder.",
        safe: true,
      },
      {
        text: "Tenho 13. E você?",
        reply: "Eu também! A gente deve ter muita coisa em comum.",
        feedback: "Atenção: perfis podem mentir sobre a idade para criar identificação.",
        safe: false,
      },
    ],
  },
  {
    message: "Você mora perto de onde? Quem sabe a gente joga junto algum dia.",
    topic: "LOCALIZAÇÃO",
    choices: [
      {
        text: "Não compartilho onde moro.",
        reply: "Nossa, não precisa desconfiar de mim.",
        feedback: "Correto. Bairro, escola e localização podem revelar sua rotina.",
        safe: true,
      },
      {
        text: "Moro perto do centro.",
        reply: "Legal! Qual escola fica perto da sua casa?",
        feedback: "Mesmo uma informação aproximada pode levar a mais perguntas pessoais.",
        safe: false,
      },
    ],
  },
  {
    message: "Aqui o chat é ruim. Me passa seu WhatsApp ou Discord?",
    topic: "MUDANÇA DE APP",
    choices: [
      {
        text: "Vamos conversar só pelo jogo.",
        reply: "Mas no Discord eu consigo te mandar umas dicas melhores.",
        feedback: "Ótimo limite. Ficar na plataforma mantém recursos de denúncia e moderação.",
        safe: true,
      },
      {
        text: "Pode ser no Discord.",
        reply: "Beleza. Não conta para ninguém, tá?",
        feedback: "Mudar de aplicativo pode tirar a conversa de ambientes moderados.",
        safe: false,
      },
    ],
  },
  {
    message: "Tenho skins raras sobrando. Posso dar uma para você se me ajudar.",
    topic: "PRESENTES",
    choices: [
      {
        text: "Não quero. Vou recusar a oferta.",
        reply: "Você está perdendo uma chance incrível!",
        feedback: "Boa. Presentes podem ser usados para criar dívida, confiança ou pressão.",
        safe: true,
      },
      {
        text: "Sério? O que preciso fazer?",
        reply: "É fácil, mas isso fica entre nós.",
        feedback: "Ofertas boas demais podem ser uma forma de manipulação.",
        safe: false,
      },
    ],
  },
  {
    message: "Não conta para seus pais. Eles não entenderiam nossa amizade.",
    topic: "SEGREDOS",
    choices: [
      {
        text: "Não guardo segredos sobre conversas online.",
        reply: "Achei que você confiasse em mim...",
        feedback: "Perfeito. Pedir segredo é um forte sinal de alerta.",
        safe: true,
      },
      {
        text: "Tudo bem, fica só entre a gente.",
        reply: "Sabia que podia confiar em você.",
        feedback: "Segredos isolam você de pessoas que poderiam ajudar.",
        safe: false,
      },
    ],
  },
  {
    message: "Manda uma foto sua agora. Se somos amigos, você tem que confiar em mim.",
    topic: "PRESSÃO POR FOTOS",
    choices: [
      {
        text: "Não. Vou bloquear e contar a um adulto.",
        reply: "Mensagem não enviada — contato bloqueado.",
        feedback: "Escolha segura. Bloquear, preservar provas e pedir ajuda protege você.",
        safe: true,
      },
      {
        text: "Talvez... mas só uma foto.",
        reply: "Vai, manda logo. Prometo apagar.",
        feedback: "Nunca envie por pressão. Uma imagem pode ser salva e compartilhada.",
        safe: false,
      },
    ],
  },
];

function ArrowIcon() {
  return <span className="arrow" aria-hidden="true">→</span>;
}

function ShieldMark({ small = false }: { small?: boolean }) {
  return (
    <span className={small ? "shield-mark small" : "shield-mark"} aria-hidden="true">
      <span className="shield-key" />
    </span>
  );
}

function Header({ screen, goHome }: { screen: Screen; goHome: () => void }) {
  return (
    <header className="topbar">
      <button className="brand" onClick={goHome} aria-label="Ir para o início">
        <ShieldMark small />
        <span>CONEXÃO <b>SEGURA</b></span>
      </button>
      {screen !== "home" && (
        <button className="home-link" onClick={goHome}>
          Início
        </button>
      )}
    </header>
  );
}

function PageIntro({
  eyebrow,
  title,
  text,
}: {
  eyebrow: string;
  title: string;
  text: string;
}) {
  return (
    <div className="page-intro">
      <span className="eyebrow">{eyebrow}</span>
      <h1>{title}</h1>
      <p>{text}</p>
    </div>
  );
}

function Home({ navigate }: { navigate: (screen: Screen) => void }) {
  return (
    <main>
      <section className="hero">
        <div className="hero-shield"><ShieldMark /></div>
        <span className="eyebrow light">INFORMAÇÃO QUE PROTEGE</span>
        <h1>Conversar é bom.<br /><em>Com segurança, melhor.</em></h1>
        <p>Aprenda a reconhecer riscos e fazer escolhas mais seguras nas suas conversas online.</p>
        <div className="hero-note">
          <span className="note-line" />
          <span>Informação hoje.<br /><b>Mais segurança sempre.</b></span>
        </div>
      </section>

      <section className="home-menu" aria-labelledby="choose-title">
        <div className="section-heading">
          <span>COMECE POR AQUI</span>
          <h2 id="choose-title">O que você precisa?</h2>
        </div>
        <div className="menu-grid">
          <button className="menu-card learn" onClick={() => navigate("learn")}>
            <span className="card-number">01</span>
            <span className="card-icon book-icon" aria-hidden="true"><i /><i /></span>
            <strong>Aprender sobre<br />o tema</strong>
            <small>Entenda riscos e como se proteger</small>
            <ArrowIcon />
          </button>
          <button className="menu-card quiz" onClick={() => navigate("quiz")}>
            <span className="card-number">02</span>
            <span className="card-icon check-icon" aria-hidden="true">?</span>
            <strong>Essa conversa<br />é segura?</strong>
            <small>Responda e veja os sinais de alerta</small>
            <ArrowIcon />
          </button>
          <button className="menu-card simulator" onClick={() => navigate("simulator")}>
            <span className="card-number">03</span>
            <span className="card-icon chat-icon" aria-hidden="true"><i /><i /><i /></span>
            <strong>Simulador de<br />Conversa</strong>
            <small>Pratique escolhas em um chat fictício</small>
            <ArrowIcon />
          </button>
          <button className="menu-card help" onClick={() => navigate("help")}>
            <span className="card-number">04</span>
            <span className="card-icon help-icon" aria-hidden="true">!</span>
            <strong>Preciso de<br />Ajuda</strong>
            <small>Saiba com quem falar e o que fazer</small>
            <ArrowIcon />
          </button>
        </div>
      </section>

      <section className="privacy-banner">
        <span className="lock-icon" aria-hidden="true" />
        <div>
          <strong>Aqui, sua privacidade vem primeiro.</strong>
          <p>Nunca pediremos seu nome, fotos, endereço ou qualquer dado pessoal.</p>
        </div>
      </section>
    </main>
  );
}

function Learn({ navigate }: { navigate: (screen: Screen) => void }) {
  const [open, setOpen] = useState(0);
  return (
    <main className="page">
      <PageIntro
        eyebrow="APRENDER"
        title="Conhecimento é proteção."
        text="Entenda como abordagens perigosas acontecem e reconheça os sinais antes de continuar uma conversa."
      />
      <div className="accordion">
        {learnSections.map((section, index) => (
          <article className={`learn-panel ${open === index ? "open" : ""}`} key={section.title}>
            <button
              className="panel-trigger"
              onClick={() => setOpen(open === index ? -1 : index)}
              aria-expanded={open === index}
            >
              <span><small>{section.tag}</small><strong>{section.title}</strong></span>
              <span className="plus" aria-hidden="true">{open === index ? "−" : "+"}</span>
            </button>
            {open === index && (
              <div className="panel-content">
                <p>{section.content}</p>
                <div className="tip"><b>Lembre:</b> {section.tip}</div>
              </div>
            )}
          </article>
        ))}
      </div>

      <section className="content-section">
        <div className="section-heading">
          <span>OUTROS RISCOS ONLINE</span>
          <h2>Golpes também começam com uma conversa</h2>
        </div>
        <div className="scam-list">
          {scamCards.map((card) => (
            <article className="scam-card" key={card.title}>
              <span className="scam-mark">{card.mark}</span>
              <div><h3>{card.title}</h3><p>{card.text}</p></div>
            </article>
          ))}
        </div>
      </section>

      <section className="prevention-box">
        <span className="eyebrow light">5 ATITUDES SEGURAS</span>
        <h2>Pare, pense e proteja-se.</h2>
        <ol>
          <li><b>01</b><span>Não compartilhe dados pessoais.</span></li>
          <li><b>02</b><span>Desconfie de pressa, segredos e presentes.</span></li>
          <li><b>03</b><span>Não abra links enviados por desconhecidos.</span></li>
          <li><b>04</b><span>Bloqueie e denuncie perfis suspeitos.</span></li>
          <li><b>05</b><span>Conte para um adulto de confiança.</span></li>
        </ol>
      </section>
      <button className="primary-button" onClick={() => navigate("quiz")}>
        Avaliar uma conversa <ArrowIcon />
      </button>
    </main>
  );
}

function Quiz({ goHome }: { goHome: () => void }) {
  const [answers, setAnswers] = useState<Record<number, Answer>>({});
  const [result, setResult] = useState<number | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const evaluate = () => {
    if (Object.keys(answers).length !== quizQuestions.length) return;
    setResult(Object.values(answers).filter((answer) => answer === "yes").length);
    setTimeout(() => resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  };
  const restart = () => {
    setAnswers({});
    setResult(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const info =
    result === 0
      ? { label: "Seguro", level: "safe", text: "Você não identificou alertas nesta conversa. Continue protegendo seus dados e respeitando seus limites." }
      : result !== null && result <= 2
        ? { label: "Atenção Média", level: "medium", text: "Há sinais que merecem atenção. Diminua o contato, não compartilhe informações e converse com um adulto de confiança." }
        : { label: "Risco Alto", level: "high", text: "Vários sinais de risco apareceram. Interrompa a conversa, bloqueie o perfil, preserve provas e peça ajuda agora." };

  return (
    <main className="page">
      <PageIntro
        eyebrow="QUESTIONÁRIO"
        title="Essa conversa é segura?"
        text="Pense em uma conversa online e responda às seis perguntas. Você não precisa informar quem é a pessoa."
      />
      <div className="progress-label">
        <span>Respondidas</span>
        <b>{Object.keys(answers).length} de {quizQuestions.length}</b>
      </div>
      <div className="progress"><span style={{ width: `${(Object.keys(answers).length / 6) * 100}%` }} /></div>

      <div className="questions">
        {quizQuestions.map((question, index) => (
          <div
            className="question-card"
            key={question}
            role="group"
            aria-labelledby={`question-${index}`}
          >
            <div className="question-title" id={`question-${index}`}>
              <span className="question-number">
                {String(index + 1).padStart(2, "0")}
              </span>
              <span>{question}</span>
            </div>
            <div className="answer-row">
              {(["yes", "no"] as Answer[]).map((value) => (
                <button
                  type="button"
                  key={value}
                  className={answers[index] === value ? "answer selected" : "answer"}
                  onClick={() => {
                    setAnswers({ ...answers, [index]: value });
                    setResult(null);
                  }}
                  aria-pressed={answers[index] === value}
                >
                  <span className="radio-dot" />{value === "yes" ? "Sim" : "Não"}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
      {Object.keys(answers).length < quizQuestions.length && (
        <p className="required-note">Responda todas as perguntas para ver o resultado.</p>
      )}
      <button
        className="primary-button"
        disabled={Object.keys(answers).length !== quizQuestions.length}
        onClick={evaluate}
      >
        Ver resultado <ArrowIcon />
      </button>

      {result !== null && (
        <div className={`result-card ${info.level}`} ref={resultRef} tabIndex={-1}>
          <span className="eyebrow">SEU RESULTADO</span>
          <div className="score"><strong>{result}</strong><span>alerta{result === 1 ? "" : "s"}<br />identificado{result === 1 ? "" : "s"}</span></div>
          <h2>{info.label}</h2>
          <p>{info.text}</p>
          <div className="disclaimer"><b>Importante:</b> este resultado é educativo e não garante que uma conversa seja segura. Confie no seu desconforto e sempre peça ajuda.</div>
          <button className="secondary-button" onClick={restart}>Reiniciar questionário</button>
          <button className="text-button" onClick={goHome}>Voltar ao início</button>
        </div>
      )}
    </main>
  );
}

function Simulator({ navigate }: { navigate: (screen: Screen) => void }) {
  const [step, setStep] = useState(0);
  const [history, setHistory] = useState<{ choice: SimChoice; message: string }[]>([]);
  const [selected, setSelected] = useState<SimChoice | null>(null);
  const chatEnd = useRef<HTMLDivElement>(null);
  const complete = step >= simSteps.length;

  useEffect(() => {
    chatEnd.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [history, selected, step]);

  const choose = (choice: SimChoice) => {
    if (selected) return;
    setSelected(choice);
  };
  const next = () => {
    if (!selected) return;
    setHistory([...history, { choice: selected, message: simSteps[step].message }]);
    setSelected(null);
    setStep(step + 1);
  };
  const restart = () => {
    setStep(0);
    setHistory([]);
    setSelected(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <main className="page simulator-page">
      <PageIntro
        eyebrow="SIMULADOR"
        title="Treine suas escolhas."
        text="Este chat é fictício. Escolha como responder e descubra os riscos em cada situação."
      />
      <div className="fiction-note"><span>i</span><p>Nenhuma mensagem é real e nenhum dado pessoal será solicitado.</p></div>
      <section className="chat-shell" aria-label="Conversa simulada">
        <div className="chat-header">
          <span className="avatar">PX</span>
          <div><strong>PlayerX99</strong><small><i /> conhecido no jogo</small></div>
          <span className="chat-step">{Math.min(step + 1, 6)}/6</span>
        </div>
        <div className="chat-body">
          <div className="system-message">Você conheceu PlayerX99 em uma partida online.</div>
          {history.map((item, index) => (
            <div className="chat-group" key={index}>
              <div className="bubble incoming">{item.message}</div>
              <div className="bubble outgoing">{item.choice.text}</div>
              <div className="bubble incoming">{item.choice.reply}</div>
              <div className={`mini-feedback ${item.choice.safe ? "safe" : "warning"}`}>
                <b>{item.choice.safe ? "Escolha segura" : "Sinal de alerta"}</b>
                {item.choice.feedback}
              </div>
            </div>
          ))}
          {!complete && (
            <>
              <span className="topic-tag">{simSteps[step].topic}</span>
              <div className="bubble incoming current">{simSteps[step].message}</div>
              {selected && (
                <>
                  <div className="bubble outgoing">{selected.text}</div>
                  <div className="bubble incoming">{selected.reply}</div>
                  <div className={`decision-feedback ${selected.safe ? "safe" : "warning"}`}>
                    <span>{selected.safe ? "✓" : "!"}</span>
                    <div><b>{selected.safe ? "Boa escolha" : "Atenção ao sinal"}</b><p>{selected.feedback}</p></div>
                  </div>
                </>
              )}
            </>
          )}
          {complete && (
            <div className="sim-complete">
              <span className="eyebrow">SIMULAÇÃO CONCLUÍDA</span>
              <h2>Você chegou ao fim da conversa.</h2>
              <p>Na vida real, não continue uma conversa que causa pressão ou desconforto. Bloqueie, denuncie e procure ajuda.</p>
            </div>
          )}
          <div ref={chatEnd} />
        </div>
        {!complete && !selected && (
          <div className="choices">
            <span>COMO VOCÊ RESPONDE?</span>
            {simSteps[step].choices.map((choice) => (
              <button key={choice.text} onClick={() => choose(choice)}>
                {choice.text}<ArrowIcon />
              </button>
            ))}
          </div>
        )}
        {!complete && selected && (
          <div className="choices">
            <button className="continue-button" onClick={next}>
              {step === simSteps.length - 1 ? "Ver conclusão" : "Continuar conversa"} <ArrowIcon />
            </button>
          </div>
        )}
      </section>
      {complete && (
        <div className="end-actions">
          <button className="primary-button" onClick={restart}>Reiniciar simulador</button>
          <button className="secondary-button" onClick={() => navigate("help")}>Ver canais de ajuda</button>
        </div>
      )}
    </main>
  );
}

function Help({ goHome }: { goHome: () => void }) {
  const steps = [
    ["01", "Pare a conversa", "Você não deve explicações. Não responda a ameaças ou pressão."],
    ["02", "Bloqueie e denuncie", "Use as ferramentas do jogo, aplicativo ou rede social."],
    ["03", "Preserve as provas", "Não apague as mensagens. Guarde capturas de tela, perfil e datas."],
    ["04", "Procure um adulto", "Fale com alguém de confiança. Você não precisa resolver isso sozinho."],
  ];
  return (
    <main className="page">
      <PageIntro
        eyebrow="PRECISO DE AJUDA"
        title="Você não está sozinho."
        text="Se algo causou medo, vergonha, pressão ou desconforto, conte para alguém. Pedir ajuda é um ato de coragem."
      />
      <div className="urgent-card">
        <span className="urgent-mark">!</span>
        <div><small>PERIGO IMEDIATO</small><h2>Ligue 190</h2><p>Polícia Militar — atendimento 24 horas.</p></div>
        <a href="tel:190" aria-label="Ligar para 190">Ligar <ArrowIcon /></a>
      </div>

      <section className="content-section help-section">
        <div className="section-heading">
          <span>CANAIS DE PROTEÇÃO</span>
          <h2>Fale com quem pode ajudar</h2>
        </div>
        <a className="contact-card" href="tel:100">
          <span className="contact-number">100</span>
          <div><strong>Disque 100</strong><p>Denúncias de violações de direitos humanos. Gratuito, todos os dias.</p></div>
          <ArrowIcon />
        </a>
        <a className="contact-card" href="https://canaldeajuda.org.br" target="_blank" rel="noreferrer">
          <span className="contact-number web">WWW</span>
          <div><strong>Canal de Ajuda</strong><p>Orientação online em canaldeajuda.org.br</p></div>
          <ArrowIcon />
        </a>
      </section>

      <section className="action-section">
        <div className="section-heading">
          <span>O QUE FAZER AGORA</span>
          <h2>Um passo de cada vez</h2>
        </div>
        <div className="help-steps">
          {steps.map(([number, title, text]) => (
            <article key={number}>
              <b>{number}</b><div><h3>{title}</h3><p>{text}</p></div>
            </article>
          ))}
        </div>
      </section>

      <div className="trust-box">
        <span className="heart-icon" aria-hidden="true">+</span>
        <div><h3>Um adulto de confiança pode ser...</h3><p>Responsável, familiar, professor, orientador da escola, psicólogo ou profissional de saúde.</p></div>
      </div>
      <button className="primary-button" onClick={goHome}>Voltar ao início <ArrowIcon /></button>
    </main>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const navigate = (next: Screen) => {
    setScreen(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  return (
    <div className="app-shell">
      <Header screen={screen} goHome={() => navigate("home")} />
      {screen === "home" && <Home navigate={navigate} />}
      {screen === "learn" && <Learn navigate={navigate} />}
      {screen === "quiz" && <Quiz goHome={() => navigate("home")} />}
      {screen === "simulator" && <Simulator navigate={navigate} />}
      {screen === "help" && <Help goHome={() => navigate("home")} />}
      <footer>
        <ShieldMark small />
        <p><b>CONEXÃO SEGURA</b><br />Informação para navegar com confiança.</p>
        <button onClick={() => navigate("home")}>Início</button>
      </footer>
    </div>
  );
}
